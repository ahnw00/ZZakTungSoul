﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy/Boss/Anim/BossAnimInstance.h"
#include <Enemy/Boss/Boss.h>

#include <GameFramework/CharacterMovementComponent.h>


UBossAnimInstance::UBossAnimInstance()
{

}

void UBossAnimInstance::NativeInitializeAnimation()
{
	Owner = Cast<ABoss>(TryGetPawnOwner());
}

void UBossAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	if (!Owner)
	{
		return;
	}

	Velocity = Owner->GetVelocity();

	if (!Velocity.IsNearlyZero())
	{
		FRotator MoveRot = Velocity.Rotation();

		FRotator PawnRot = Owner->GetActorRotation();

		Speed = Velocity.Size();
		Direction = FMath::FindDeltaAngleDegrees(PawnRot.Yaw, MoveRot.Yaw);
	}
}
