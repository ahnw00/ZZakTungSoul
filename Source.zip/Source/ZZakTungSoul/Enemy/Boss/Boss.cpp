﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy/Boss/Boss.h"
#include <Enemy/EnemyAIController.h>
#include <Enemy/Data/EnemyAIData.h>
#include <Enemy/Components/AttackTraceComponent.h>
#include <Enemy/Components/EnemyStatComponent.h>
#include <Character/CharacterStatComponent.h>
#include <Interface/CombatDamageInterface.h>
#include <Data/DamageInfo.h>

#include <GameFramework/CharacterMovementComponent.h>
#include <Components/StaticMeshComponent.h>
#include <Components/SkeletalMeshComponent.h>
#include <Engine/StaticMesh.h>

ABoss::ABoss()
{
	// Mesh setting
	static ConstructorHelpers::FObjectFinder<USkeletalMesh> SkeletonMeshRef(
		TEXT("/Game/Assets/Clown_monster/Meshes/base_mesh/SKM_base_mesh.SKM_base_mesh")
	);

	if (SkeletonMeshRef.Succeeded())
	{
		GetMesh()->SetSkeletalMesh(SkeletonMeshRef.Object);

		GetMesh()->SetRelativeLocation(FVector(0, 0, -90));
		GetMesh()->SetRelativeRotation(FRotator(0, -90, 0));

		GetMesh()->SetAnimationMode(EAnimationMode::AnimationBlueprint);
		static ConstructorHelpers::FClassFinder<UAnimInstance> AnimClassRef(
			TEXT("/Game/Blueprints/Enemy/Boss/Anim/ABP_Boss.ABP_Boss_C")
		);

		if (AnimClassRef.Succeeded())
		{
			GetMesh()->SetAnimInstanceClass(AnimClassRef.Class);
		}
		else
		{

		}
	}
}

void ABoss::BeginPlay()
{
	Super::BeginPlay();


}

void ABoss::ReceiveDamage(const FDamageInfo& DamageInfo, const FHitResult& Hit)
{

}

void ABoss::UpdateMovementSpeed()
{

}

void ABoss::UpdateRotationMode()
{}

void ABoss::HandleAttackTraceHit(const FHitResult & Hit)
{}

void ABoss::InitializeWeapon()
{

}
