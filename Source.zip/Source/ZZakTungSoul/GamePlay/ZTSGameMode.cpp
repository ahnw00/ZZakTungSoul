﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "GamePlay/ZTSGameMode.h"
#include <Kismet/GameplayStatics.h>
#include <Warrior/WarriorPlayerState.h>
#include "Warrior/WarriorController.h"

AZTSGameMode::AZTSGameMode()
{
	// 컨트롤러 세팅
	PlayerControllerClass = AWarriorController::StaticClass();
	PlayerStateClass = AWarriorPlayerState::StaticClass();

	// 컨트롤러로 조종하는 Pawn 세팅
	static ConstructorHelpers::FClassFinder<APawn> WarriorClassRef(
		TEXT("/Game/Blueprints/Warrior/BP_Warrior.BP_Warrior_C")
	);

	if (WarriorClassRef.Succeeded())
	{
		DefaultPawnClass = WarriorClassRef.Class;
	}
}

void AZTSGameMode::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);

	// 레벨 열릴 때 LoadGame 옵션 붙어 있는 지 검사.
	if (UGameplayStatics::HasOption(Options, TEXT("LoadGame")))
	{
		bShouldLoadOnStart = true;
		UE_LOG(LogTemp, Log, TEXT("[GameMode] LoadGame 옵션 감지. BeginPlay에서 세이브 로드합니다."));
	}
}

void AZTSGameMode::BeginPlay()
{
	Super::BeginPlay();

	// 타이틀에서 [LoadGame]으로 들어왔다면 자동으로 세이브 로드.
	if (bShouldLoadOnStart)
	{
		LoadGame();
	}
}

UWarriorPlayerSaveGame* AZTSGameMode::GetSaveGame()
{
	// 저장된 데이터가 있으면 그거 반환
	if (UGameplayStatics::DoesSaveGameExist(SlotName, 0))
	{
		UWarriorPlayerSaveGame* WarriorLoadGame =
			Cast<UWarriorPlayerSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));

		if (WarriorLoadGame)
			return WarriorLoadGame;
	}

	// 저장된 데이터가 없으면 생성해서 반환
	UWarriorPlayerSaveGame* WarriorNewGame =
		Cast<UWarriorPlayerSaveGame>(UGameplayStatics::CreateSaveGameObject(UWarriorPlayerSaveGame::StaticClass()));
	return WarriorNewGame;
}

void AZTSGameMode::SaveGame()
{
	UWarriorPlayerSaveGame* WarriorSaveGame = GetSaveGame();

	AWarriorPlayerState* WarriorPlayerState =
		GetWorld()->GetFirstPlayerController()->GetPlayerState<AWarriorPlayerState>();
	if (!WarriorPlayerState)
	{
		UE_LOG(LogTemp, Log, TEXT("No WarriorPlayerState"));
		return;
	}

	// PlayerState에서 저장할 데이터 가져오기
	WarriorSaveGame->SetSaveData(WarriorPlayerState->GetSaveData());

	// 저장해주기
	if (!UGameplayStatics::SaveGameToSlot(WarriorSaveGame, SlotName, 0))
	{
		UE_LOG(LogTemp, Log, TEXT("Cannot save WarriorSaveGame"));
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("WarriorData Saved"));
}

void AZTSGameMode::LoadGame()
{
	// 저장 데이터 없으면 return
	if (!UGameplayStatics::DoesSaveGameExist(SlotName, 0))
	{
		UE_LOG(LogTemp, Log, TEXT("There is no data saved"));
		return;
	}

	// 저장 데이터가 존재한다면
	if (UGameplayStatics::DoesSaveGameExist(SlotName, 0))
	{
		// 저장 데이터 캐스팅
		if(UWarriorPlayerSaveGame* WarriorLoadGame =
			Cast<UWarriorPlayerSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName, 0)))
		{
			// WarriorPlayerState 가져오기
			if(AWarriorPlayerState* WarriorPlayerState = 
				GetWorld()->GetFirstPlayerController()->GetPlayerState<AWarriorPlayerState>())
			{
				// PlayerState로 정보 로드
				WarriorPlayerState->LoadSaveDataFrom(WarriorLoadGame->GetSaveData());
				UE_LOG(LogTemp, Log, TEXT("Warrior Data Loaded"));

				// 마지막 상호작용 화톳불로 순간이동.
				const FName LastBonfireID = WarriorPlayerState->GetLastBonfireID();
				if (!LastBonfireID.IsNone())
				{
					if (AWarriorController* PC = Cast<AWarriorController>(GetWorld()->GetFirstPlayerController()))
					{
						PC->TeleportToBonfire(LastBonfireID);
						UE_LOG(LogTemp, Log, TEXT("[GameMode] 마지막 화톳불(%s) 위치로 이동 완료."), *LastBonfireID.ToString());
					}
				}
			}
			else
			{
				UE_LOG(LogTemp, Log, TEXT("WarriorPlayerState not loaded"));
			}
		}
	}
}

void AZTSGameMode::DeleteGame()
{
	if (UGameplayStatics::DoesSaveGameExist(SlotName, 0))
	{
		UGameplayStatics::DeleteGameInSlot(SlotName, 0);
	}
}


